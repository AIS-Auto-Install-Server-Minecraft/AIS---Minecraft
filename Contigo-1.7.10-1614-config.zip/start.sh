echo "Arcrow tu me casses les couilles a pas vouloir fix ce fichier"
java -Xms128m -Xmx8g -jar server.jar nogui
