echo "Lancement du serveur... (2Go de ram par défaut) | Spigot 1.13"
java -Xms128m -Xmx2g -jar spigot-1.13.jar nogui
