echo "Lancement du serveur... (2Go de ram par défaut) | Spigot 1.15"
java -Xms128m -Xmx2g -jar spigot-1.15.jar nogui
