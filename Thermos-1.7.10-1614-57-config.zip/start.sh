echo "Lancement du serveur... (2Go de ram par défaut) | Thermos-1.7.10-1614-57"
java -Xms128m -Xmx2g -jar Thermos-1.7.10-1614-57-server.jar nogui
